package com.example
import org.junit.Assert.assertEquals
import org.junit.Test
import java.time.LocalTime
import java.time.format.DateTimeFormatter

class ExampleUnitTest {
    @Test fun formats24HourTime() {
        val result = LocalTime.of(23, 7, 5).format(DateTimeFormatter.ofPattern("HH:mm:ss"))
        assertEquals("23:07:05", result)
    }
}
