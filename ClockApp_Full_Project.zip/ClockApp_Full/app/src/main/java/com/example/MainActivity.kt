package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import com.example.clock.ClockViewModel
import com.example.ui.ClockScreen
import com.example.ui.theme.ClockTheme

class MainActivity : ComponentActivity() {
    private val viewModel: ClockViewModel by viewModels()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ClockTheme {
                val state by viewModel.state.collectAsState()
                ClockScreen(state)
            }
        }
    }
}
