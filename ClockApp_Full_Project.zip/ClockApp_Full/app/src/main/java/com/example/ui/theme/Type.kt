package com.example.ui.theme
import androidx.compose.material3.Typography
val ClockTypography = Typography()
