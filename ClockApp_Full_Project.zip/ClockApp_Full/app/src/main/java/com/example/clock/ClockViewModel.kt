package com.example.clock

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class ClockViewModel : ViewModel() {
    private val _state = MutableStateFlow(ClockState())
    val state: StateFlow<ClockState> = _state.asStateFlow()
    private val timeFormatter = DateTimeFormatter.ofPattern("HH:mm:ss", Locale.getDefault())
    private val dateFormatter = DateTimeFormatter.ofPattern("EEEE, dd MMMM yyyy", Locale.getDefault())

    init {
        viewModelScope.launch {
            while (true) {
                val now = LocalDateTime.now(ZoneId.systemDefault())
                val time = now.format(timeFormatter)
                _state.value = ClockState(
                    hours = time.substring(0, 2),
                    minutes = time.substring(3, 5),
                    seconds = time.substring(6, 8),
                    dateLabel = now.format(dateFormatter).uppercase(Locale.getDefault())
                )
                delay(1000L - (System.currentTimeMillis() % 1000L))
            }
        }
    }
}
