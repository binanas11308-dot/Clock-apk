package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.clock.ClockState

@Composable
fun ClockScreen(state: ClockState) {
    Box(
        modifier = Modifier.fillMaxSize().background(Color(0xFF101012)).padding(horizontal = 20.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = state.dateLabel,
                color = Color(0xFFB8B8BA),
                fontSize = 16.sp,
                fontWeight = FontWeight.Medium,
                letterSpacing = 1.2.sp,
                textAlign = TextAlign.Center
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(state.hours, color = Color(0xFFF5F5F5), fontSize = 58.sp,
                    fontWeight = FontWeight.Black, letterSpacing = (-1.5).sp)
                Text(":", color = Color(0xFFF5F5F5), fontSize = 58.sp, fontWeight = FontWeight.Black)
                Text(state.minutes, color = Color(0xFFFF6B1A), fontSize = 58.sp,
                    fontWeight = FontWeight.Black, letterSpacing = (-1.5).sp)
                Text(":", color = Color(0xFFF5F5F5), fontSize = 58.sp, fontWeight = FontWeight.Black)
                Text(state.seconds, color = Color(0xFFF5F5F5), fontSize = 58.sp,
                    fontWeight = FontWeight.Black, letterSpacing = (-1.5).sp)
            }
        }
    }
}
