package com.example.ui.theme
import androidx.compose.ui.graphics.Color
val DarkCharcoal = Color(0xFF101012)
val DarkSurface = Color(0xFF16161A)
val ClockWhite = Color(0xFFF5F5F5)
val ClockOrange = Color(0xFFFF6B1A)
