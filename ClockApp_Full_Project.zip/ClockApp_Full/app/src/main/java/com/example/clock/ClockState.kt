package com.example.clock

data class ClockState(
    val hours: String = "00",
    val minutes: String = "00",
    val seconds: String = "00",
    val dateLabel: String = ""
)
