package com.example.ui.theme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
private val ClockColors = darkColorScheme(
    primary = ClockOrange, background = DarkCharcoal, surface = DarkSurface,
    onBackground = ClockWhite, onSurface = ClockWhite
)
@Composable fun ClockTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = ClockColors, typography = ClockTypography, content = content)
}
